#include "fftw3.h"
#include "math.h"
#include "iostream"

using namespace std;

int main()
{

    const unsigned int kernel_length = 10;
    double *w = new double[kernel_length];
    fftw_complex *kernel, *inSignal, *convolution;
    fftw_complex *kernel_fft, *inSignal_f, *convolution_f;
    fftw_plan     p, pinv;
    const double scale = 1./kernel_length;

    kernel = (fftw_complex *)fftw_malloc(sizeof(fftw_complex) * kernel_length);
    inSignal    = (fftw_complex *)fftw_malloc(sizeof(fftw_complex) * kernel_length);
    convolution = (fftw_complex *)fftw_malloc(sizeof(fftw_complex) * kernel_length);
    kernel_fft = (fftw_complex *)fftw_malloc(sizeof(fftw_complex) * kernel_length);
    inSignal_f    = (fftw_complex *)fftw_malloc(sizeof(fftw_complex) * kernel_length);
    convolution_f    = (fftw_complex *)fftw_malloc(sizeof(fftw_complex) * kernel_length);


    // fill input array for distances
    for (int i = 0; i < kernel_length; ++i)
    {
        w[i] = (-i / (0.5 * 2));
        kernel[i][0] = w[i];
        kernel[i][1] = 0;
    }

    // fill input array for sNMDAs
    for (int i = 0; i < kernel_length; ++i)
    {
        inSignal[i][0] = 1;
        inSignal[i][1] = 0;
    }

    p = fftw_plan_dft_1d(kernel_length,
                         kernel,
                         kernel_fft,
                         FFTW_FORWARD,
                         FFTW_ESTIMATE);

    fftw_execute(p);

    p = fftw_plan_dft_1d(kernel_length,
                         inSignal,
                         inSignal_f,
                         FFTW_FORWARD,
                         FFTW_ESTIMATE);
    fftw_execute(p);

    // convolution in frequency domain
    for(unsigned int i = 0; i < kernel_length; ++i)
    {
        convolution_f[i][0] = (kernel_fft[i][0] * inSignal_f[i][0] + kernel_fft[i][1] * inSignal_f[i][1]) * scale;
        convolution_f[i][1] = (kernel_fft[i][0] * inSignal_f[i][1] + kernel_fft[i][1] * inSignal_f[i][0]) * scale;
    }

    pinv = fftw_plan_dft_1d(kernel_length,
                            convolution_f,
                            convolution,
                            FFTW_BACKWARD,
                            FFTW_ESTIMATE);
    fftw_execute(pinv);

    // compute and compare with expected result
    for (int i = 0; i < kernel_length; i++)
    {
        double expected = 0;

        for (int j = 0; j < kernel_length; j++)
        {
            if((i-j) >=0 && (i-j) < kernel_length){
                expected += w[i - j] ;
            }
//            cout << "Executed: " << " w["<< i << "-" << j << "] = " << w[i - j] << endl;
        }
        printf("i=%d, FFT: r%f, i%f : Expected: %f\n", i, convolution[i][0], convolution[i][1], expected);
    }

    fftw_destroy_plan(p);
    fftw_destroy_plan(pinv);

    fftw_free(kernel); fftw_free(inSignal); fftw_free(convolution);
    fftw_free(kernel_fft); fftw_free(inSignal_f); fftw_free(convolution_f);
}
